
//class PixeColor to store attributes of pixel(xCoordinate,yCoordinate,Color)

public class PixelColor {

	// Declaring variables and initializing variables
	private int xCoordinate;
	private int yCoordinate;
	private int pixColor;

	/***********************************************
	 * Getters and setters
	 ***********************************************/
	public int getxCoordinate() {
		return xCoordinate;
	}

	public void setxCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}

	public int getyCoordinate() {
		return yCoordinate;
	}

	public void setyCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}

	public int getPixColor() {
		return pixColor;
	}

	public void setPixColor(int pixColor) {
		this.pixColor = pixColor;
	}

}
